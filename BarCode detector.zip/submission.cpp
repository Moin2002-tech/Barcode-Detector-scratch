// QR-Code-Assignment
#include <opencv2/opencv.hpp>
#include <opencv2/objdetect.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <string>

using namespace std;
using namespace cv;


int main(){
	// Image Path
	string imgPath = DATA_PATH + "/images/IDCard-Satya.png";

	// Read image and store it in variable img
	///
	/// YOUR CODE HERE
	///
	
	cout << img.size().height << " " << img.size().width;
	
	Mat bbox, rectifiedImage;

	// Create a QRCodeDetector Object
	// Variable name should be qrDecoder
	///
	/// YOUR CODE HERE
	///

	// Detect QR Code in the Image
	// Output should be stored in opencvData
	///
	/// YOUR CODE HERE
	///

	// Check if a QR Code has been detected
	if(opencvData.length()>0)
		cout << "QR Code Detected" << endl;
	else
		cout << "QR Code NOT Detected" << endl;
	
	int n = bbox.rows;

	// Draw the bounding box
	///
	/// YOUR CODE HERE
	///
	
	// Since we have already detected and decoded the QR Code
	// using qrDecoder.detectAndDecode, we will directly
	// use the decoded text we obtained at that step (opencvData)

	cout << "QR Code Detected!" << endl;
	///
	/// YOUR CODE HERE
	///
	
	// Write the result image
	string resultImagePath = "./QRCode-Output.png";

	///
	/// YOUR CODE HERE
	///
	
	return 0;
}